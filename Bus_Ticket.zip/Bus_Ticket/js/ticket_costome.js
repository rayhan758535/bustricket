$(document).ready(function () {
    $(document).on("scroll", onScroll);
  
    //smoothscroll
    $('a[href^="#"]').on('click', function (e) {
        e.preventDefault();
        if(!$(this).hasClass( "dropdown-toggle" )){
          $(document).off("scroll");
          if($('.main-sidebar').length<1){
            $('.menu-left ul li a').each(function () {
              $(this).removeClass('active');
             $(this).next( ".nav-bar" ).css('display', 'none');
            });
          }
         $(this).addClass('active');
         $(this).next( ".nav-bar" ).css('display', 'block');
    
          var target = this.hash,
          $target = $(target);
          $('html, body').stop().animate({
              'scrollTop': $target.offset().top+2
          }, 500, 'swing', function () {
              window.location.hash = target;
              $(document).on("scroll", onScroll);
          });
        }
  
    });
  
    function onScroll(event){
      var scrollPos = document.body.scrollTop || document.documentElement.scrollTop;
      $('.menu-left ul li  a').each(function () {
          var currLink = $(this);
          var refElement = $(currLink.attr("href"));
          if($(this).text()!=='Contact'){
            if (refElement.offset().top <= scrollPos && refElement.offset().top + refElement.height() > scrollPos) {
                $('.menu-left ul li  a').removeClass("active");
                $('.menu-left ul li  a').next( ".nav-bar" ).css('display', 'none');
                currLink.addClass("active");
                currLink.next( ".nav-bar" ).css('display', 'block');
            }
            else{
                currLink.removeClass("active");
                currLink.next( ".nav-bar" ).css('display', 'none');
            }
          }
      });
    }
   
    // //SP Menu
    // $(".sp-nav-menu-icon").click(function(){
    //   $(this).toggleClass("change");
    //   $("#sp-icon").toggleClass("sp-cross")
    //   $("#full-menu-sp").toggleClass("show");
    //   $('body').toggleClass("overhide");
    // });
  
   
    /**
    * Active header menu selected bar
    *
    * @author 
    * @method POST / GET
    * @param
    * @header
    * @return
    * @redirect
    * @throws
    * @access
    * @static
    * @since
    */
    if($('.release-app').length){
      activeSelectedBarHeaderMenu('Release');
    }
    if($('.team-management').length){
      activeSelectedBarHeaderMenu('Team');
    }
    if($('.project-title-create-step2').length){
      activeSelectedBarHeaderMenu('Scene');
    }
    if($('.iot-management').length){
      activeSelectedBarHeaderMenu('IoT management');
    }
    function activeSelectedBarHeaderMenu(e){
      $('.menu-left a').each(function(){
        $(this).removeClass('active');
        if($(this).text()== e){
          $(this).addClass('active');
        }
      });
    }
  });
  $(window).on('load resize', function(){
  
    var screenWidth = $('body').innerWidth();
    var wWidth=$(window ).width();
     // home top menu hover nav bar show
     $('.home-menu .menu-left ul li a').hover(function(){
      $(this).next( ".nav-bar" ).css({
        'display':'block'
      });
     }, function () {
      if(!$(this).hasClass("active")){
        $(this).next( ".nav-bar" ).css({
          'display':'none'
        });
      }
    });
    
    // after login top menu hover nav bar show
    $('.mainnav .menu-left ul li a').hover(function(){
      $(this).next( ".nav-bar" ).css({
        'display':'block'
      });
    }, function () {
      if(!$(this).hasClass("active")){
        $(this).next( ".nav-bar" ).css({
          'display':'none'
        });
      }
    });
     //home top menu nav bar show
     $('.home-menu .menu-left ul li').each(function () {
      if ($(this).find('a').hasClass("active")) {
        $(this).find( ".nav-bar" ).css({
          'display':'block'
        });
      }
    });
    // after login top menu nav bar show
    $('.mainnav .menu-left ul li').each(function () {
      if ($(this).find('a').hasClass("active")) {
        $(this).find( ".nav-bar" ).css({
          'display':'block'
        });
      }
    });
    // after login menu ratio adjust
    if(wWidth<=1068 && wWidth>=751){
      $('.mainnav .menu-left ul').css({
        'margin-left':'0'
      });
    }else{
      $('.mainnav .menu-left ul').css({
        'margin-left':'5%'
      });
    }
  
    // after login menu left logo to middle
    if((wWidth<=931 && wWidth>=751)){
      $('.mainnav .menu-left').css({
        'padding-top': ($(".mainnav").height()-$(".mainnav .menu-logo").height()-17)/2,
      });
    }else if(wWidth>931){
      $('.mainnav .menu-left').css({
        'padding-top': ($(".mainnav").height()-$(".mainnav .menu-logo").height()+3-15)/2,
      });
    }
    // on load after home menu logo middle
    $('.home-menu .logo').css({
      'padding-top':($(".home-menu").height()-$(".home-menu .logo").height()-15)/2
    });
  
    // on load after login menu logo middle
    $('.mainnav .menu-logo').css({
      'padding-top':($(".mainnav").height()-$(".mainnav .menu-logo").height()-15)/2
    });
  
    // on load after login menu  middle
    $('.mainnav .menu-left').css({
      'padding-top': ($(".mainnav").height()-$(".mainnav .menu-logo").height()+3-15)/2,
    });
  
    // after login top right user info middle
    $('.mainnav .menu-dropdown').css({
      'padding-top': ($(".mainnav").height()-$(".mainnav .menu-dropdown").height()-6)/2,
    })
  
   
  });
  
   // Dropdown toggle
   $('.dropdown-toggle').click(function(){
    $(this).next('.dropdown').toggle();
  });
  
  $(document).click(function(e) {
    var target = e.target;
    if (!$(target).is('.dropdown-toggle') && !$(target).parents().is('.dropdown-toggle')) {
      $('.dropdown').hide();
    }
  });
  